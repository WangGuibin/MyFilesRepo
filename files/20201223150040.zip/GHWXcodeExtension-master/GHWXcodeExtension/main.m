//
//  main.m
//  GHWXcodeExtension
//
//  Created by 黑化肥发灰 on 2019/8/29.
//  Copyright © 2019 黑化肥发灰. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
