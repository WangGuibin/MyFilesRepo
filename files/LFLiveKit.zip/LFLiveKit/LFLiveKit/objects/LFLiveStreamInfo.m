//
//  LFLiveStreamInfo.m
//  LFLiveKit
//
//  Created by LaiFeng on 16/5/20.
//  Copyright © 2016年 LaiFeng All rights reserved.
//

#import "LFLiveStreamInfo.h"

@implementation LFLiveStreamInfo

@end
